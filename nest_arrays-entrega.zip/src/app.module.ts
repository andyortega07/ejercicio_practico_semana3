import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { ProductosModule } from './productos/productos.module';
import { ConfigModule } from '@nestjs/config';
import { PedidoModule } from './pedido/pedido.module';
import { PrismaModule } from './prisma/prisma.module';
import { ReservasController } from './reservas/reservas.controller';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    PrismaModule,
    ProductosModule,
    PedidoModule,
  ],
  controllers: [AppController, ReservasController],
  providers: [AppService],
})
export class AppModule {}
